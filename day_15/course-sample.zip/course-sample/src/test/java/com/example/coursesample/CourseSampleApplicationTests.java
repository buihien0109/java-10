package com.example.coursesample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourseSampleApplicationTests {

    @Test
    void contextLoads() {
    }

}
