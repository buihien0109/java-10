package com.example.userbackend.database;

import com.example.userbackend.model.User;

import java.util.ArrayList;
import java.util.List;

public class FakeDB {
    public static List<User> users = new ArrayList<>();
}
