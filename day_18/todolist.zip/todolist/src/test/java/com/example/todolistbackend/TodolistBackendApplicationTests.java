package com.example.todolistbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TodolistBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
